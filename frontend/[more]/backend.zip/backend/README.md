# exam-scheduler

System for assignment and scheduling of supervision duties to course examination in universities
