package gr.aueb.app.domain;

public enum Period {
    WINTER, SPRING, SEPTEMBER
}
