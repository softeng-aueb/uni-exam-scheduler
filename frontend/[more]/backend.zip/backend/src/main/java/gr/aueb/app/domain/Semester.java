package gr.aueb.app.domain;

public enum Semester {
    FIRST, SECOND, THIRD, FOURTH, FIFTH, SIXTH, SEVENTH, EIGHTH
}
