package gr.aueb.app.domain;

public enum SupervisorCategory {
    EDIP, ETEP, PHD, DISPATCHED, EXTERNAL
}
