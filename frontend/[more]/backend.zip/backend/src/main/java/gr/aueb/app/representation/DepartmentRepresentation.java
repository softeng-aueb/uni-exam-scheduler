package gr.aueb.app.representation;

import io.quarkus.runtime.annotations.RegisterForReflection;

@RegisterForReflection
public class DepartmentRepresentation {
    public Integer id;
    public String name;
}
